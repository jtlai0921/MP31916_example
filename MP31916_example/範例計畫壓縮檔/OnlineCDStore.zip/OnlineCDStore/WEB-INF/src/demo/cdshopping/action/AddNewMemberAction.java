package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;

/**
 * Add new member action.
 * 
 * @author FengShuo Yu
 */
public class AddNewMemberAction extends AbstractAction {
	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {

		// if come here, that means add new member succeeded
		// so, go and see the shopping card summary
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/OrderSummary.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in LoginAction");
			e.printStackTrace();
		}

	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
		String username = (String)request.getReq().getParameter("username");
		String password = (String)request.getReq().getParameter("password");
		String name = new String(request.getReq().getParameter("name").getBytes("ISO8859_1"));
		//String name = (String)request.getReq().getParameter("name");
		String gender = (String)request.getReq().getParameter("gender");
		String address = new String(request.getReq().getParameter("address").getBytes("ISO8859_1")); 
		//String address = (String)request.getReq().getParameter("address");
		String email = (String)request.getReq().getParameter("email");
		MemberService ms = (MemberServiceImpl)getService("MemberService");
		int result = ms.addNewMember(username, password, name, gender, address, email);
		if(result !=0){
			// successful
			doView(request);
		}else {
			request.getReq().setAttribute("Error", "Can not add new member!");
			doErrorView(request);
		}
	}
	
	protected void doErrorView(OnlineShoppingRequest request)
		throws SQLException, IOException {
			javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/Error.jsp");
			try {
				dispatcher.forward(request.getReq()  ,request.getResponse()); 
			}catch(Exception e){
				System.out.println("Error: Can not doView() in AddNewMemberAction");
				e.printStackTrace();
			}

	}	

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub
	}

}
