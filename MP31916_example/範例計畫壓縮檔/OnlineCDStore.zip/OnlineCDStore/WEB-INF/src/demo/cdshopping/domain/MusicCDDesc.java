package demo.cdshopping.domain;

import java.sql.*;
import demo.cdshopping.bean.*;
import demo.cdshopping.framework.persistence.*;

/**
 * MusicCDDesc entity.
 * 
 * @author FengShuo Yu
 */
public class MusicCDDesc extends Persistable implements java.io.Serializable{
	public String musicCDID = null;
	public String title = null;
	public String singer = null;
	public double unitPrice = 0.0;
	public String style = null;
	public int numOfDisks = 0;
	public String onlinePrice = null;
	public String gender = null;
	public String language = null;
	/**
	 * @return
	 */
	public String getGender() {
		return gender;
	}


	/**
	 * @return
	 */
	public int getNumOfDisks() {
		return numOfDisks;
	}

	/**
	 * @return
	 */
	public String getOnlinePrice() {
		return onlinePrice;
	}

	/**
	 * @return
	 */
	public String getSinger() {
		return singer;
	}

	/**
	 * @return
	 */
	public String getStyle() {
		return style;
	}

	/**
	 * @return
	 */
	public String getTitle() {
		return title;
	}

	/**
	 * @return
	 */
	public double getUnitPrice() {
		return unitPrice;
	}

	/**
	 * @param string
	 */
	public void setGender(String string) {
		gender = string;
	}



	/**
	 * @param i
	 */
	public void setNumOfDisks(int i) {
		numOfDisks = i;
	}

	/**
	 * @param string
	 */
	public void setOnlinePrice(String string) {
		onlinePrice = string;
	}

	/**
	 * @param string
	 */
	public void setSinger(String string) {
		singer = string;
	}

	/**
	 * @param string
	 */
	public void setStyle(String string) {
		style = string;
	}

	/**
	 * @param string
	 */
	public void setTitle(String string) {
		title = string;
	}

	/**
	 * @param d
	 */
	public void setUnitPrice(double d) {
		unitPrice = d;
	}

	/**
	 * @return
	 */
	public String getMusicCDID() {
		return musicCDID;
	}

	/**
	 * @param string
	 */
	public void setMusicCDID(String string) {
		musicCDID = string;
	}

	/**
	 * @return
	 */
	public String getLanguage() {
		return language;
	}

	/**
	 * @param string
	 */
	public void setLanguage(String string) {
		language = string;
	}
	/**
	 * Get song list for secific cd.
	 * 
	 * @param cd
	 * @return
	 */
	public SongList getSongList(){
		SongList list = new SongList();
		String query = "select * from songdesc where musiccdid='" + this.getMusicCDID()+ "'";
		JDBCConnector db = new JDBCConnector();
		try{
			Connection conn = getDBConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				// create
				SongDesc song = new SongDesc();
				// fill
				song.setParent(this);
				song.setName(rs.getString("songname"));
				song.setOrder(rs.getString("order"));
				// add
				list.add(song);
			}
			if(rs != null){
				rs.close();
			}
			closeDBConnection(conn);
		}catch(Exception e){
			e.printStackTrace();
		}
		return list;
	}
	


	/**
	 * Get cd reviews.
	 * 
	 * @param cd
	 * @return
	 */
	public Reviews getReviews(){
		Reviews list = new Reviews();

		String query = "select * from review where musiccdid='" + this.getMusicCDID()+ "'";
		JDBCConnector db = new JDBCConnector();
		try{
			Connection conn = getDBConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				// create
				Review review = new Review();
				// fill
				review.setContent(rs.getString("content"));
				review.setParent(this);
				review.setMemberID(rs.getString("memberid"));
				// add
				list.add(review);
			}
			if(rs != null){
				rs.close();
			}
			closeDBConnection(conn);
		}catch(Exception e){
			e.printStackTrace();
		}		
		return list;
	}

	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		return 0;
	}		
}
