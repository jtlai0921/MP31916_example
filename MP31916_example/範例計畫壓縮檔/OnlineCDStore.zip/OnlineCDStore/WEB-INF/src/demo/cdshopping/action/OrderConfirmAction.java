package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;


import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.*;
import demo.cdshopping.domain.*;


/**
 * Confirm order action.
 * 
 * @author FengShuo Yu
 */
public class OrderConfirmAction extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/ThankYou.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in OrderConfirmAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
		// populate order
		Account acct = (Account) request.getReq().getSession().getAttribute("account");
		ShoppingCart sc = getShoppingCart(request);
		Order order = new Order();
		order.setMemberID(acct.getMemberID());
		//order.setPurchaseDate(new Date());
		order.setTotal(sc.getTotal());
		order.save();
	
		// populate order item
		Vector items = sc.getContents();
		String memberID = acct.getMemberID();
		for(int i = 0; i < items.size(); i++){
			LineItem lineitem = (LineItem) items.elementAt(i);
			OrderItem orderItem = new OrderItem();
			orderItem.setItemID(lineitem.getCd().getMusicCDID());
			orderItem.setOrderID(order.getOrderID());
			orderItem.setQuantity(lineitem.getQuantity());
			orderItem.save();			
		}
		
		// clean up shopping cart
		this.removeShoppingCart(request);
		request.getReq().setAttribute("confirmNumber", order.getOrderID());
		
		// dispatch to thank you
		doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub

	}

}
