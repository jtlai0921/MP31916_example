package demo.cdshopping.framework.service;
import demo.cdshopping.domain.*;
/**
 * Logic service interface.
 * 
 * @author FengShuo Yu
 */
public interface MemberService {
	public int addNewMember(String username, String password, String name, String gender, String address, String email);
	public Account login(String username, String password);
}
