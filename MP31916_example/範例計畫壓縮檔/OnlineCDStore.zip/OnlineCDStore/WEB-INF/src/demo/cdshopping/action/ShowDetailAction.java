package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;
import demo.cdshopping.bean.*;

/**
 * Display shopping cart detail.
 * 
 * @author FengShuo Yu
 */
public class ShowDetailAction extends AbstractAction {
	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/ViewCDDetail.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in ViewCatalogAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
			String cdid = (String)request.getReq().getParameter("cdid");
			
			CatalogService service = (CatalogServiceImpl)getService("CatalogService");
			Catalog catalog = service.getCatalog();
			MusicCDDetail cdDetail = catalog.getMusicCDDetail(cdid);
			request.getReq().setAttribute("cddetail", cdDetail);
			// ready for next view
			doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub
	}
}
