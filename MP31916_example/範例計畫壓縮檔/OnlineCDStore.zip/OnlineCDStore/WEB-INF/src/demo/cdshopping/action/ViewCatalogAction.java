package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.framework.service.*;
import demo.cdshopping.bean.*;

/**
 * View CD Catalog action.
 * 
 * @author FengShuo Yu
 */
public class ViewCatalogAction extends AbstractAction {
	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}
	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		// just call the JSP view
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/ViewCatalog.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in ViewCatalogAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
		
		CatalogService service = (CatalogService)getService("CatalogService");
		Catalog catalog = service.getCatalog();
		// add model to servlet request object
		request.getReq().setAttribute("catalog", catalog); // set as request level
		doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub
	}

}
