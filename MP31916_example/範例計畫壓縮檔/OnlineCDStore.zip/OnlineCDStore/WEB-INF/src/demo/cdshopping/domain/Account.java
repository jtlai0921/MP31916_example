package demo.cdshopping.domain;

import demo.cdshopping.framework.persistence.*;

/**
 * Account entity.
 * 
 * @author FengShuo Yu
 */
public class Account extends Persistable implements java.io.Serializable{
	public String memberID = "";
	public String userName = "";
	public String password = "";
	/**
	 * @return
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @return
	 */
	public String getPassword() {
		return password;
	}

	/**
	 * @return
	 */
	public String getUserName() {
		return userName;
	}

	/**
	 * @param string
	 */
	public void setMemberID(String string) {
		memberID = string;
	}

	/**
	 * @param string
	 */
	public void setPassword(String string) {
		password = string;
	}

	/**
	 * @param string
	 */
	public void setUserName(String string) {
		userName = string;
	}

	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		return 0;
	}	

}
