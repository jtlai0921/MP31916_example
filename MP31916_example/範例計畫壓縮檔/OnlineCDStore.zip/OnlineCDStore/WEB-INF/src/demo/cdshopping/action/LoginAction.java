package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;
import demo.cdshopping.domain.*;

/**
 * Login in action.
 * 
 * @author FengShuo Yu
 */
public class LoginAction extends AbstractAction {
	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}
	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}
	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}
	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/OrderSummary.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in LoginAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}
	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
		MemberService ms = (MemberServiceImpl)getService("MemberService");
		String username = (String)request.getReq().getParameter("username");
		String password = (String)request.getReq().getParameter("password");
		Account account = ms.login(username, password);
		// the above line mean to simplify the following tree step.
		// create account
		// set attribute
		// calling account.isValid() - hit DB
		if(account != null){
			//save account for later use
			request.getReq().getSession().setAttribute("account", account);
			// successful login
			doView(request);
		}else {
			// dispatch to NewMember.jsp
			doNewMemberView(request);
		}
	}

	/**
	 * 
	 * @param request
	 * @throws SQLException
	 * @throws IOException
	 */
	protected void doNewMemberView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/NewMember.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in LoginAction");
			e.printStackTrace();
		}
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub
	}
}
