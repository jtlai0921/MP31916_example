package demo.cdshopping.domain;

import demo.cdshopping.framework.persistence.*;
/**
 * Customer entity.
 * 
 * @author FengShuo Yu
 */
public class Customer  extends Persistable implements java.io.Serializable{
	public String customerID = "";
	public String sex = "";
	public String custName = "";
	public String phone = "";
	public String fax = "";
	public String address = "";
	public String email = "";
	
	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		return 0;
	}
}
