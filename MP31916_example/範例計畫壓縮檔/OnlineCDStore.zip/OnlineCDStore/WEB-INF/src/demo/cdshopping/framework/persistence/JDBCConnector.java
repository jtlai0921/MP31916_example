package demo.cdshopping.framework.persistence;

import java.sql.*;

/**
 * JDBC connector.
 * 
 * @author FengShuo Yu
 */
public class JDBCConnector {
	/* Easy way to hack.
	 * 
	 * Should read value from outside instead of hard-coded here. 
	 */
	private static String url = "jdbc:odbc:driver={Microsoft Access Driver (*.mdb)};DBQ=C:\\eclipse-OnlineCDStore\\workspace\\OnlineCDStore\\MusicCD.mdb";
	public Connection getConnection(){
		Connection conn = null;
		try {
			Class.forName("sun.jdbc.odbc.JdbcOdbcDriver");
			conn = DriverManager.getConnection(url, "","");		
		}catch(Exception e){
			e.printStackTrace();
		}
		return conn;
	}
	
	/**
	 * Just close for now. Should be ported to connection pool.
	 * @param conn
	 */
	public void returnConnection(Connection conn){
		try {
			if(conn != null) {
				conn.close();
				conn = null;
			}
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
