package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.*;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.*;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;

/**
 * Search CD by name.
 * 
 * @author FengShuo Yu
 */
public class SearchMusicCDByName extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		// TODO Auto-generated method stub
		// just call the JSP view
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/SearchResult.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in SearchBookByNameAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}


	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
			String name1=new String(request.getReq().getParameter("keyword").getBytes("ISO8859_1")); 
			CatalogService service = (CatalogServiceImpl)getService("CatalogService");
			Catalog cat = service.getCatalog();
			CDList list = (CDList) cat.searchMusicCDByName(name1);

//			List result = service.searchMusicCDByName(name1);
			
			// add model to servlet request object
			request.getReq().setAttribute("cdlist", list);
			doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub
	}
}
