package demo.cdshopping.controller;

import javax.servlet.http.*;
import javax.servlet.*;
import java.io.*;
import java.sql.*;
import java.util.*;
import java.lang.reflect.InvocationTargetException;
import java.lang.reflect.Method;

import demo.cdshopping.bean.*;
import demo.cdshopping.framework.action.*;
import demo.cdshopping.util.*;


/**
 * Entry point for this web application, implemented as servlet.
 * 
 * @author FengShuo Yu
 */
public class ControllerServlet extends HttpServlet {
	
	ServletContext servletContext = null; // will need to use this when calling JSP
	
	/**/
	public void doGet(HttpServletRequest req, HttpServletResponse response) throws IOException {
		try{
			perform(req, response);
		}catch(Exception e){
		}
		
	}
	
	/**/
	public void doPost(HttpServletRequest req, HttpServletResponse response) throws IOException {
		try{
			perform(req, response);
		}catch(Exception e){
		}
	}	
	
	public void init(ServletConfig config) throws ServletException {
		servletContext = config.getServletContext(); 
		System.out.println("OnlineBookStore init()");
		
		
		// Initialize application components
		// initialize web application parameters from servlet config
		initParameters(config);
		// initialize log4j
		//initLog();
		// load application specific properties
		loadAppProperties();
		
		Enumeration enum = Application.getProperties().keys();
		while(enum.hasMoreElements()) {
			String masterKey = (String) enum.nextElement();
			// initialize application components
			if(masterKey.substring(0, 3).equals("app")){
				String clazzName = (String) Application.getProperties().get(masterKey);
				
				initAppComponent(clazzName);
				
			}
			

		}	
	}	
	
	
	private void initAppComponent(String clazzName){
		//log.debug("Entering");
		try {
			Class clazz = Class.forName(clazzName);
			Method initMethod = clazz.getMethod("init", new Class[0]); // invoke init() method
			initMethod.invoke(clazz, new Object[0]);
		}catch(ClassNotFoundException e){
			//log.error("Class Not Found: " + clazzName);
		}catch(NoSuchMethodException e){
			//log.error("No Such Method (init()) Exception: " + clazzName);
		}catch(IllegalAccessException e){
			//log.error("Illegal Access Exception: " + clazzName);
		}catch(InvocationTargetException e){
			//log.error("Invocation Target Exception: " + clazzName);
		}
		//log.debug("Exiting");
	}
	
		
	private void loadAppProperties()throws ServletException{
		
		try {
			File propsFile = new File(ApplicationConstants.APPLICATION_PROPERTIES_PATH);
			FileInputStream fis = new FileInputStream(propsFile);
			Application.getProperties().load(fis);
			//log.debug("Exiting");
		}catch(FileNotFoundException e) {
			//log.error(e.getMessage(), e);
			throw new ServletException("File not found: " + ApplicationConstants.APPLICATION_PROPERTIES_PATH);
		}catch(IOException e) {
			//log.error(e.getMessage(), e);
			throw new ServletException("IOException: " + ApplicationConstants.APPLICATION_PROPERTIES_PATH);
		}
		
	}	

	private void initParameters(ServletConfig config) throws ServletException{
		if (config != null) {
			// set up applicaiton root
			ApplicationConstants.APP_ROOT = config.getInitParameter(ApplicationConstants.APP_ROOT_TAG);
			// set up application properties path
			String relAppProperties = config.getInitParameter(ApplicationConstants.APPLICATION_PROPERTIES_TAG);
			String path = ApplicationConstants.APP_ROOT + relAppProperties;
			ApplicationConstants.APPLICATION_PROPERTIES_PATH = path;
			// set up log4j properties path
			//String relLog4jProperties = config.getInitParameter(ApplicationConstants.LOG4J_PATH_TAG);
			//String log4j_path = ApplicationConstants.APP_ROOT + relLog4jProperties;
			//ApplicationConstants.LOG4J_PATH = log4j_path;
			
			//String testreportformat = config.getInitParameter(ApplicationConstants.TEST_REPORT_FORMAT_TAG);
			//ApplicationConstants.TEST_REPORT_FORMAT = testreportformat;
			
			//CAL_LOGOUT_URL = config.getInitParameter(ApplicationConstants.CAS_LOGOUT_URL_TAG);
		} else {
		}
	}	
	private void initRequest(HttpServletRequest req, HttpServletResponse response, OnlineShoppingRequest er) {
		
		
		er.setReq(req);
		er.setResponse(response);
		er.setServletContext(this.servletContext);

		
	}	
	
	/**
	 * A simple workflow for processing client's request. 
	 * 
	 * Using Template pattern and command pattern.
	 * 
	 * @param req
	 * @param response
	 * @throws IOException
	 * @throws SQLException
	 */
	private void perform(HttpServletRequest req, HttpServletResponse response) throws IOException, SQLException {
		System.out.println("Under Construction");
		OnlineShoppingRequest request = new OnlineShoppingRequest();
		initRequest(req, response, request);
		AbstractAction ea = (AbstractAction) getAction(request);	
		ea.execute(request);	
		
	}
	
	private AbstractAction getAction(OnlineShoppingRequest request) {
	
		String destination = request.getReq().getServletPath();
		destination = destination.substring(1, destination.length());
		AbstractAction action = (AbstractAction) ActionFactory.getAction(destination);
		
		return action;
	}	
	
	protected void service(HttpServletRequest req, HttpServletResponse response) throws ServletException, IOException {
		System.out.println("Calling service() in controller");
		try{
			perform(req, response);
		}catch(Exception e){
			e.printStackTrace();
		}
	}
}
