package demo.cdshopping.service;

import java.sql.*;

import demo.cdshopping.framework.persistence.*;
import demo.cdshopping.domain.*;
import demo.cdshopping.framework.service.*;

/**
 * Member service implementation.
 * 
 * @author FengShuo Yu
 */
public class MemberServiceImpl extends Service implements MemberService{
	public MemberServiceImpl(){
		super("MemberService");
	}
	
	public Account login(String username, String password){
		String query = "select * from Account where username = '" + 
						username + "' and password = '"+password+"'";
		
		JDBCConnector db = new JDBCConnector();
		Account account = null;
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.next()) {
				account = new Account();
				account.setMemberID(rs.getString("MemberID"));
				account.setUserName(username);
				account.setPassword(password);
			}
			if(rs != null){
				rs.close();
			}
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}

		return account;
	}
	
	/**
	 * Should be in atomic action, for now, just forget it.
	 *  
	 * @param username
	 * @param password
	 * @param name
	 * @param gender
	 * @param address
	 * @param email
	 * @return
	 */
	public int addNewMember(String username, String password, String name, String gender, String address, String email){
		String query = "insert into Member (Gender, Name, Address, Email) values ('" +
		gender + "', '" + name + "', '" + address + "', '" + email + "'" 
		+ ")";
		
		System.out.println(query);
		
		JDBCConnector db = new JDBCConnector();
		int result = 0;
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}
		
		if(result == 0 ) return 0; // no need to continue
		
		///////////////////////////////////////////////////////////////////// select it out
		
		String querySelect = "select * from Member where name ='" + username + "' and email='" + email + "'"; 
		System.out.println(querySelect);
		String memberid = null;
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(querySelect);
			if (rs.next()) {
				memberid = rs.getString("memberid");
			}
			if(rs != null){
				rs.close();
			}
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}		
		
		
		if(memberid == null){
			return 0; // no need to continue;
		}

		
		/////////////////////////////////////////////////////////////////////////
		String queryAccount = "insert into Account (memberid, username, password) values ('" +
				memberid + "', '" + username + "', '" + password + "')";
		
		System.out.println(queryAccount);
		result = 0; // reset
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			result = stmt.executeUpdate(queryAccount);
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}

		return result;
	}
}
