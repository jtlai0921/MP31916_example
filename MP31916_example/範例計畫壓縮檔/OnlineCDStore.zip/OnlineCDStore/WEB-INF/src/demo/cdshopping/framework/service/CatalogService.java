package demo.cdshopping.framework.service;

import java.sql.*;
import java.util.*;

import demo.cdshopping.domain.*;
import demo.cdshopping.bean.*;
/**
 * Catalog service interface.
 * 
 * @author FengShuo Yu
 */
public interface CatalogService {
	public Catalog getCatalog() throws SQLException;
	public MusicCDDesc getMusicCDDetail(String musicCDid);
	public List searchMusicCDByName(String keyword);
}
