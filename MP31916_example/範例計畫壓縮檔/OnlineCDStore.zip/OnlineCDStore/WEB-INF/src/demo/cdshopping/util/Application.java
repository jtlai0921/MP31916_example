package demo.cdshopping.util;

import java.util.Properties;

/**
 * Application specific constants repository.
 * 
 * @author FengShuo Yu
 */
public class Application {
	public static Properties properties = new Properties();
	/**
	 * @return Properties
	 */
	public static Properties getProperties() {
		return properties;
	}

	/**
	 * Sets the properties.
	 * @param properties The properties to set
	 */
	public static void setProperties(Properties properties) {
		Application.properties = properties;
	}

}
