package demo.cdshopping.domain;

import java.sql.*;
import demo.cdshopping.framework.persistence.*;

/**
 * Order entity.
 * 
 * @author FengShuo Yu
 */
public class Order extends Persistable implements java.io.Serializable{
	public String orderID = null;
	public String memberID = null;
	public String purchaseDate = null;
	public float total = 0;
	/**
	 * @return
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @return
	 */
	public String getPurchaseDate() {
		return purchaseDate;
	}

	/**
	 * @return
	 */
	public float getTotal() {
		return total;
	}

	/**
	 * @param string
	 */
	public void setMemberID(String string) {
		memberID = string;
	}

	/**
	 * @param string
	 */
	public void setPurchaseDate(String string) {
		purchaseDate = string;
	}

	/**
	 * @param f
	 */
	public void setTotal(float f) {
		total = f;
	}
	
	/**
	 * @return
	 */
	public String getOrderID() {
		return orderID;
	}

	/**
	 * @param string
	 */
	public void setOrderID(String string) {
		orderID = string;
	}
		
	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		this.orderID = getOrderNumber()+"";
		String query = "insert into CustomerOrder (OrderID, MemberID, Total) values ('" +
		this.orderID + "', '" + this.memberID + "', " + this.total + ")";
		
		int result = 0;
		try{
			Connection conn = getDBConnection();
			Statement stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			closeDBConnection(conn);
		}catch(Exception e){
			e.printStackTrace();
		}		
		return result;
	}

	/**
	 * Generate order number.
	 * 
	 * @return
	 */
	public int getOrderNumber(){
		String query = "select * from OrderNumber";
		
		JDBCConnector db = new JDBCConnector();
		int orderNumber = 0;
		
		try{
			Connection conn = getDBConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			if (rs.next()) {
				orderNumber = rs.getInt("orderNumber");
			}
			if(rs != null){
				rs.close();
			}
			closeDBConnection(conn);
			
			String Iquery = "update OrderNumber set OrderNumber=" + (orderNumber+1);
			conn = getDBConnection();
			stmt = conn.createStatement();
			stmt.executeUpdate(Iquery);		
			closeDBConnection(conn);
		}catch(Exception e){
			e.printStackTrace();
		}
		return orderNumber;
	}
}
