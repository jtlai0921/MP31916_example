package demo.cdshopping.bean;

import java.util.*;

/**
 * CDList bean.
 * 
 * @author FengShuo Yu
 */
public class CDList extends ArrayList implements java.io.Serializable{
	public List result = new ArrayList();
}
