package demo.cdshopping.bean;

import java.io.Serializable;
import java.util.*;

import demo.cdshopping.domain.*;
/**
 * ShoppingCart bean.
 * 
 * @author FengShuo Yu
 */
public class ShoppingCart implements Serializable {
	public Vector contents = new Vector();
	/**
	 * @return
	 */
	public Vector getContents() {
		return contents;
	}

	/**
	 * @param vector
	 */
	public void setContents(Vector vector) {
		contents = vector;
	}
	
	/**
	 * Check to see if cd exist in shopping cart.
	 * 
	 * @param cdid
	 * @return
	 */
	public boolean existInCart(String cdid){
		boolean inCart = false;
		if(contents != null && contents.size()>0){
			for(int i = 0 ; i < contents.size(); i++){
				LineItem item = (LineItem)contents.get(i);
				if(cdid.equals(item.getCd().getMusicCDID()))
					inCart = true;
			}
		}
		return inCart;
	}
	
	/** 
	 * Get line item.
	 * 
	 * @param bookid
	 * @return
	 */
	public LineItem getLineItem(String bookid){
		LineItem item = null;
		LineItem itemTemp = null;
		for(int i = 0 ; i < contents.size(); i++){
			itemTemp = (LineItem)contents.get(i);
			if(bookid.equals(itemTemp.getCd().getMusicCDID()))
			item = itemTemp;
		}
		return item;
		
	}
	
	/**
	 * Add line item.
	 * 
	 * @param cd
	 * @param quantity
	 */	
	public void addLineItem(MusicCDDesc cd, int quantity){
		LineItem item = new LineItem();
		item.setCd(cd);
		item.setQuantity(quantity);
		
		getContents().add(item);
	}
	
	/**
	 * Add line item.
	 * 
	 * @param item
	 */
	public void addLineItem(LineItem item){
		getContents().add(item);
	}
	
	/**
	 * Get total.
	 * 
	 * @return
	 */
	public float getTotal(){
		float sum = 0;
		for(int i = 0; i < getContents().size(); i++) {
			LineItem item = (LineItem) contents.elementAt(i);
			sum = sum + item.getSubtotal();
		}
		return sum;
	}
	
	


}
