package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;
import demo.cdshopping.domain.*;
import demo.cdshopping.bean.*;

/**
 * Add product to shoppintcart action.
 * 
 * @author FengShuo Yu
 */
public class AddToCartAction extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
			
			CatalogService service = (CatalogServiceImpl) getService("CatalogService");
			Catalog catalog = service.getCatalog();
			// add model to servlet request object
			request.getReq().setAttribute("catalog", catalog);
			
			
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/ViewCatalog.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in AddToCartAction");
			e.printStackTrace();
		}

	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {

		//syncModelWithGUI(request);
		ShoppingCart sc = getShoppingCart(request);

		// take out the book id which the user would like to add to shopping cart
		String cdid = (String)request.getReq().getParameter("cdid");
		String quantity = (String)request.getReq().getParameter("quantity");

		if(sc.existInCart(cdid)){
			//update quantity in shopping cart
			LineItem itemFound = sc.getLineItem(cdid);
			itemFound.setQuantity(Integer.parseInt(quantity));
		}else {
			// added request cd (new)
			CatalogService service = (CatalogServiceImpl)getService("CatalogService");
			Catalog cat = service.getCatalog();
			MusicCDDesc cd = cat.getMusicCD(cdid);
			//MusicCDDesc cd = service.getMusicCDDetail(cdid);
			LineItem item = new LineItem();
			item.setCd(cd);
			item.setQuantity(Integer.parseInt(quantity));
			sc.addLineItem(item);
		}	
		request.getReq().removeAttribute("cd"); // if any, just incase
		// ready for next view
		doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {

	}
}
