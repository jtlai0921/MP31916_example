package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;

/**
 * Check out action.
 * 
 * @author FengShuo Yu
 */
public class CheckOutAction extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/OrderSummary.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in LoginAction");
			e.printStackTrace();
		}

	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {	
		Object account = request.getReq().getSession().getAttribute("account");
		if(account == null){ // not login yet
			doLoginView(request);
		}
		else {
			// ready for next view
			doView(request);
		}
	}
	
	/**
	 * dispatch to login view.
	 * 
	 * @param request
	 * @throws SQLException
	 * @throws IOException
	 */
	private void doLoginView(OnlineShoppingRequest request)
		throws SQLException, IOException {
			
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/Login.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in CheckOutAction");
			e.printStackTrace();
		}
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub

	}

}
