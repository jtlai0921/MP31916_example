package demo.cdshopping.service;

import java.util.*;
import java.sql.*;

import demo.cdshopping.framework.persistence.*;
import demo.cdshopping.domain.*;
import demo.cdshopping.bean.*;
import demo.cdshopping.framework.service.*;

/**
 * Catalog service implementation.
 * 
 * @author FengShuo Yu
 */
public class CatalogServiceImpl extends Service implements CatalogService {
	public CatalogServiceImpl(){
		super("CatalogService");
	}
	/**
	 * Get catalog from database.
	 * 
	 * @return
	 * @throws SQLException
	 */
	public Catalog getCatalog() throws SQLException{
		String query = "select * from MusicCDDesc order by musiccdid";
		
		JDBCConnector db = new JDBCConnector();
		Catalog catalog = new Catalog();
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				MusicCDDesc cd = new MusicCDDesc();
				cd.setMusicCDID(rs.getString("musicCDID"));
				cd.setSinger(rs.getString("singer"));
				cd.setTitle(rs.getString("title"));
				cd.setUnitPrice(rs.getDouble("unitPrice"));
				cd.setStyle(rs.getString("style"));
				cd.setNumOfDisks(rs.getInt("numberofdisks"));
				cd.setOnlinePrice(rs.getString("onlineprice"));
				cd.setGender(rs.getString("gender"));
				cd.setLanguage(rs.getString("language"));
				catalog.addMusicCD(cd);
			}
			if(rs != null){
				rs.close();
			}
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}
		return catalog;
	}

	/**
	 * Get CD Detail information.
	 * 
	 * @param bookid
	 * @return
	 */	
	public MusicCDDesc getMusicCDDetail(String musicCDid){
		
		String query = "select * from MusicCDDesc where musiccdid='"+musicCDid+"'";
		MusicCDDesc cd = null;
		JDBCConnector db = new JDBCConnector();
		try{
			Connection conn = db.getConnection();

			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				cd = new MusicCDDesc();
				cd.setMusicCDID(rs.getString("musicCDID"));
				cd.setSinger(rs.getString("singer"));
				cd.setTitle(rs.getString("title"));
				cd.setUnitPrice(rs.getDouble("unitPrice"));
			}
			if(rs != null){
				rs.close();
			}
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}
		return cd;
	}
	
	/**
	 * Search CD by Name.
	 * 
	 * @param keyword
	 * @return
	 */
	public List searchMusicCDByName(String keyword){
		CDList result = new CDList();
		/* DON'T use " in statement for MS Access, use ' */
		String query = "SELECT * from MusicCDDesc where Singer  like '%"+keyword+"%'";
		System.out.println(query);
		
		JDBCConnector db = new JDBCConnector();
		try{
			Connection conn = db.getConnection();
			Statement stmt = conn.createStatement();
			ResultSet rs = stmt.executeQuery(query);
			while (rs.next()) {
				MusicCDDesc cd = new MusicCDDesc();
				cd.setMusicCDID(rs.getString("musicCDID"));
				cd.setSinger(rs.getString("singer"));
				cd.setTitle(rs.getString("title"));
				cd.setUnitPrice(rs.getDouble("unitPrice"));
				result.add(cd);
			}
			if(rs != null){
				rs.close();
			}
			conn.close();
			conn = null;
		}catch(Exception e){
			e.printStackTrace();
		}
		return result;
	}
}
