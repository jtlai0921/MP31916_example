package demo.cdshopping.bean;

import java.io.Serializable;
import demo.cdshopping.domain.*;
/**
 * LineItem bean.
 * 
 * @author FengShuo Yu
 */
public class LineItem implements Serializable {
	public MusicCDDesc cd;
	public int quantity; 

	/**
	 * @return
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param i
	 */
	public void setQuantity(int i) {
		quantity = i;
	}

	/**
	 * @return
	 */
	public MusicCDDesc getCd() {
		return cd;
	}

	/**
	 * @param desc
	 */
	public void setCd(MusicCDDesc desc) {
		cd = desc;
	}

	public float getSubtotal(){
		// get unit price
		double unitPrice = cd.getUnitPrice();
		// calculate sub total
		float subTotal = this.quantity * Float.parseFloat(unitPrice+"");
		return subTotal;
	}
}
