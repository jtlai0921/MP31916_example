package demo.cdshopping.domain;

import java.sql.*;
import demo.cdshopping.framework.persistence.*;

/**
 * OrderItem entity.
 * 
 * @author FengShuo Yu
 */
public class OrderItem extends Persistable implements java.io.Serializable{
	public String orderID = null;
	public String ItemID = null;
	public int quantity = 0;
	/**
	 * @return
	 */
	public String getItemID() {
		return ItemID;
	}

	/**
	 * @return
	 */
	public String getOrderID() {
		return orderID;
	}

	/**
	 * @param string
	 */
	public void setItemID(String string) {
		ItemID = string;
	}

	/**
	 * @param string
	 */
	public void setOrderID(String string) {
		orderID = string;
	}
	
	/**
	 * Save order item information.
	 * 
	 * @return
	 */
	public int save(){		
		String query = "insert into OrderItem (MusicCDID, OrderID, Quantity) values ('" +
		this.ItemID + "', '" + this.orderID + "', '" + this.quantity + "')";
		int result = 0;
		try{
			Connection conn = getDBConnection();
			Statement stmt = conn.createStatement();
			result = stmt.executeUpdate(query);
			closeDBConnection(conn);
		}catch(Exception e){
			e.printStackTrace();
		}		
		return result;
	}	

	/**
	 * @return
	 */
	public int getQuantity() {
		return quantity;
	}

	/**
	 * @param i
	 */
	public void setQuantity(int i) {
		quantity = i;
	}

}
