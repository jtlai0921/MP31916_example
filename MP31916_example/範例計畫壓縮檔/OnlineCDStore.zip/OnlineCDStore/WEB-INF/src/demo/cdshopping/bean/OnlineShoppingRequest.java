package demo.cdshopping.bean;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.*;
/**
 * OnlineShoppingRequest bean.
 * 
 * @author FengShuo Yu
 */
public class OnlineShoppingRequest {
	private ServletContext servletContext = null;
	/**
	 * Http request.
	 */
	private HttpServletRequest req = null;
	/**
	 * Http response.
	 */
	private HttpServletResponse response = null;
	/**
	 * @return
	 */
	public HttpServletRequest getReq() {
		return req;
	}

	/**
	 * @return
	 */
	public HttpServletResponse getResponse() {
		return response;
	}

	/**
	 * @param request
	 */
	public void setReq(HttpServletRequest request) {
		req = request;
	}

	/**
	 * @param response
	 */
	public void setResponse(HttpServletResponse response) {
		this.response = response;
	}

	/**
	 * @return
	 */
	public ServletContext getServletContext() {
		return servletContext;
	}

	/**
	 * @param context
	 */
	public void setServletContext(ServletContext context) {
		servletContext = context;
	}

}
