package demo.cdshopping.domain;

import demo.cdshopping.framework.persistence.*;

/**
 * SongDesc entity.
 * 
 * @author FengShuo Yu
 */
public class SongDesc extends Persistable implements java.io.Serializable{
	public MusicCDDesc parent = null;
	public String name = null;
	public String order = null;
	/**
	 * @return
	 */
	public String getName() {
		return name;
	}

	/**
	 * @return
	 */
	public String getOrder() {
		return order;
	}

	/**
	 * @param string
	 */
	public void setName(String string) {
		name = string;
	}

	/**
	 * @param string
	 */
	public void setOrder(String string) {
		order = string;
	}

	/**
	 * @return
	 */
	public MusicCDDesc getParent() {
		return parent;
	}

	/**
	 * @param desc
	 */
	public void setParent(MusicCDDesc desc) {
		parent = desc;
	}

	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		return 0;
	}	
}
