package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.bean.*;
/**
 * View shopping cart.
 * 
 * @author FengShuo Yu
 */
public class ViewCartAction extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/ViewCart.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in ViewCartAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {
		
		// double check 
		ShoppingCart sc = this.getShoppingCart(request);
		doView(request);
	}


	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub

	}

}
