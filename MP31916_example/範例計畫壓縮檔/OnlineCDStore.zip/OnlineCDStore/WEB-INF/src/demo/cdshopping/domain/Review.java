package demo.cdshopping.domain;

import demo.cdshopping.framework.persistence.*;

/**
 * Review entity.
 * 
 * @author FengShuo Yu
 */
public class Review extends Persistable implements java.io.Serializable{
	public MusicCDDesc parent = null;
	public String content = null;
	public String memberID = null;
	public String timeSubmit = null;
	
	/**
	 * @return
	 */
	public String getContent() {
		return content;
	}

	/**
	 * @return
	 */
	public String getMemberID() {
		return memberID;
	}

	/**
	 * @return
	 */
	public MusicCDDesc getParent() {
		return parent;
	}

	/**
	 * @return
	 */
	public String getTimeSubmit() {
		return timeSubmit;
	}

	/**
	 * @param string
	 */
	public void setContent(String string) {
		content = string;
	}

	/**
	 * @param string
	 */
	public void setMemberID(String string) {
		memberID = string;
	}

	/**
	 * @param desc
	 */
	public void setParent(MusicCDDesc desc) {
		parent = desc;
	}

	/**
	 * @param string
	 */
	public void setTimeSubmit(String string) {
		timeSubmit = string;
	}

	/**
	 * Save.
	 * 
	 * @return
	 */
	public int save(){
		return 0;
	}	
}
