package demo.cdshopping.action;

import java.io.IOException;
import java.sql.SQLException;
import java.util.Collection;

import demo.cdshopping.framework.action.*;
import demo.cdshopping.bean.OnlineShoppingRequest;
import demo.cdshopping.service.*;
import demo.cdshopping.framework.service.*;
import demo.cdshopping.domain.*;
import demo.cdshopping.bean.*;

/**
 * Add product quantity action.
 * 
 * @author FengShuo Yu
 */
public class AddQuantityAction extends AbstractAction {

	protected void doUpdate(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub
	}

	protected void doDelete(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected void doInsert(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	protected Collection getModel(OnlineShoppingRequest request)
		throws SQLException {
		// TODO Auto-generated method stub
		return null;
	}

	protected void doView(OnlineShoppingRequest request)
		throws SQLException, IOException {
		javax.servlet.RequestDispatcher dispatcher = request.getServletContext().getRequestDispatcher("/AddQuantity.jsp");
		try {
			dispatcher.forward(request.getReq()  ,request.getResponse()); 
		}catch(Exception e){
			System.out.println("Error: Can not doView() in ViewCatalogAction");
			e.printStackTrace();
		}
	}

	protected String getModuleName() {
		// TODO Auto-generated method stub
		return null;
	}

	public void updateModel(OnlineShoppingRequest request) {
		// TODO Auto-generated method stub

	}

	public void process(OnlineShoppingRequest request)
		throws SQLException, IOException {

		ShoppingCart sc = getShoppingCart(request);
		
		// take out the book id which the user would like to add to shopping cart
		String cdid = (String)request.getReq().getParameter("cdid");
		
		MusicCDDesc cd = null;
		// check to see if item has been added to cart before
		if(sc.existInCart(cdid)){
			//add quantity
			LineItem itemFound = sc.getLineItem(cdid);
			cd = itemFound.getCd();
			request.getReq().setAttribute("quantity", itemFound.getQuantity()+"");
		}else {
			// added request cd (new)
			CatalogService service = (CatalogServiceImpl)getService("CatalogService");
			cd = service.getMusicCDDetail(cdid);
			request.getReq().setAttribute("quantity", "1");	
		}
		request.getReq().setAttribute("cd", cd);
		// ready for next view
		doView(request);
	}

	public void syncModelWithGUI(OnlineShoppingRequest request)
		throws IOException {
		// TODO Auto-generated method stub

	}

}
