package demo.cdshopping.bean;
import demo.cdshopping.domain.*;

/**
 * MusicCDDetail bean.
 * 
 * @author FengShuo Yu
 */
public class MusicCDDetail implements java.io.Serializable{
	public MusicCDDesc cd = null;
	public Reviews reviews = null;
	public SongList songList = null;
	/**
	 * @return
	 */
	public MusicCDDesc getCd() {
		return cd;
	}

	/**
	 * @return
	 */
	public Reviews getReview() {
		return reviews;
	}

	/**
	 * @return
	 */
	public SongList getSongList() {
		return songList;
	}

	/**
	 * @param desc
	 */
	public void setCd(MusicCDDesc desc) {
		cd = desc;
	}

	/**
	 * @param review
	 */
	public void setReview(Reviews reviews) {
		this.reviews = reviews;
	}

	/**
	 * @param list
	 */
	public void setSongList(SongList list) {
		songList = list;
	}

}
