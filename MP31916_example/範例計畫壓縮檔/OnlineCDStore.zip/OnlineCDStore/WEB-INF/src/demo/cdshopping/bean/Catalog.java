package demo.cdshopping.bean;

import java.util.*;

import demo.cdshopping.domain.*;

/**
 * Catalog bean.
 * 
 * @author FengShuo Yu
 */
public class Catalog implements java.io.Serializable{
	public ArrayList cds = new ArrayList();
	
	public void addMusicCD(MusicCDDesc cd){
		cds.add(cd);
	}

	/**
	 * @return
	 */
	public ArrayList getCds() {
		return cds;
	}

	/**
	 * @param list
	 */
	public void setCds(ArrayList list) {
		cds = list;
	}
		
	/**
	 * Get cd detail information.
	 * 
	 * @param cdid
	 * @return
	 */
	public MusicCDDetail getMusicCDDetail(String cdid){
		MusicCDDesc cd = null;
		MusicCDDesc cdFound = null;
		
		for(int i=0; i < getCds().size(); i++){
			cd = (MusicCDDesc)getCds().get(i);
			if(cd.getMusicCDID().equals(cdid)){
				cdFound = cd;
				break;
			}
		}
		
		MusicCDDetail cdd = new MusicCDDetail();
		cdd.setCd(cdFound);
		// get song list
		SongList songList = cdFound.getSongList();
		cdd.setSongList(songList);
		// get song review if any
		Reviews reviews = cdFound.getReviews();
		cdd.setReview(reviews);
		return cdd;
	}
	
	/**
	 * Search cd by name.
	 * 
	 * @param keyword
	 * @return
	 */
	public List searchMusicCDByName(String keyword){
		CDList list = new CDList();
		MusicCDDesc cd = null;
		for(int i=0; i < getCds().size(); i++){
			cd = (MusicCDDesc)getCds().get(i);
			if(cd.getSinger().equals(keyword)){
				list.add(cd);
			}
		}
		return list;
	}
	
	/**
	 * Get cd.
	 * 
	 * @param cdid
	 * @return
	 */
	public MusicCDDesc getMusicCD(String cdid){
		MusicCDDesc cdFound = null;
		MusicCDDesc cd = null;
		for(int i=0; i < getCds().size(); i++){
			cd = (MusicCDDesc)getCds().get(i);
			if(cd.getMusicCDID().equals(cdid)){
				cdFound = cd;
			}
		}
		return cdFound;
	}
}
