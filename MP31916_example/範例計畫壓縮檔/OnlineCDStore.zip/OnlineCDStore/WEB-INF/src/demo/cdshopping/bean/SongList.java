package demo.cdshopping.bean;
import java.util.*;

import demo.cdshopping.domain.MusicCDDesc;
/**
 * SongList bean.
 * 
 * @author FengShuo Yu
 */
public class SongList extends ArrayList implements java.io.Serializable{
	public MusicCDDesc parent = null;

	/**
	 * @return
	 */
	public MusicCDDesc getParent() {
		return parent;
	}



	/**
	 * @param desc
	 */
	public void setParent(MusicCDDesc desc) {
		parent = desc;
	}



}
