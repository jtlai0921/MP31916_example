package demo.cdshopping.framework.persistence;

import java.sql.*;

/**
 * Abstract class for persistable entity.
 * 
 * @author FengShuo Yu
 */
public abstract class Persistable {

	/**
	 * Retrieve database connection.
	 * 
	 * @return
	 */
	protected Connection getDBConnection() {
		JDBCConnector db = new JDBCConnector();
		Connection conn = db.getConnection();
		return conn;
	}

	/**
	 * Close databse connection.
	 * 
	 * @param conn
	 */
	protected void closeDBConnection(Connection conn) {
		try {
			if (conn != null)
				conn.close();
			conn = null;
		} catch (Exception e) {
			e.printStackTrace();
		}

	}
	
	protected abstract int save();
}
