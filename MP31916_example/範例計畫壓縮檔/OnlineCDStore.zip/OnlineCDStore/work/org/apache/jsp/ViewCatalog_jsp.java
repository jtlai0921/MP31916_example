package org.apache.jsp;

import javax.servlet.*;
import javax.servlet.http.*;
import javax.servlet.jsp.*;
import demo.cdshopping.bean.*;
import demo.cdshopping.domain.*;
import java.util.*;

public final class ViewCatalog_jsp extends org.apache.jasper.runtime.HttpJspBase
    implements org.apache.jasper.runtime.JspSourceDependent {

  private static java.util.Vector _jspx_dependants;

  public java.util.List getDependants() {
    return _jspx_dependants;
  }

  public void _jspService(HttpServletRequest request, HttpServletResponse response)
        throws java.io.IOException, ServletException {

    JspFactory _jspxFactory = null;
    PageContext pageContext = null;
    HttpSession session = null;
    ServletContext application = null;
    ServletConfig config = null;
    JspWriter out = null;
    Object page = this;
    JspWriter _jspx_out = null;
    PageContext _jspx_page_context = null;


    try {
      _jspxFactory = JspFactory.getDefaultFactory();
      response.setContentType("text/html; charset=big5");
      pageContext = _jspxFactory.getPageContext(this, request, response,
      			null, true, 8192, true);
      _jspx_page_context = pageContext;
      application = pageContext.getServletContext();
      config = pageContext.getServletConfig();
      session = pageContext.getSession();
      out = pageContext.getOut();
      _jspx_out = out;

      out.write(" \r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("\r\n");
      demo.cdshopping.bean.Catalog catalog = null;
      synchronized (_jspx_page_context) {
        catalog = (demo.cdshopping.bean.Catalog) _jspx_page_context.getAttribute("catalog", PageContext.PAGE_SCOPE);
        if (catalog == null){
          catalog = new demo.cdshopping.bean.Catalog();
          _jspx_page_context.setAttribute("catalog", catalog, PageContext.PAGE_SCOPE);
        }
      }
      out.write("\r\n");
      out.write("\r\n");
      out.write("<HTML>\r\n");
      out.write("<HEAD>\r\n");
      out.write("<META HTTP-EQUIV=\"Content-Type\" CONTENT=\"text/html; charset=big5\">\r\n");
      out.write("<TITLE>歡迎光臨 - 線上音樂CD購物中心</TITLE>\r\n");
      out.write("<link rel=\"stylesheet\" type=\"text/css\" href=\"css/demo.css\" />\r\n");
      out.write("<script language=\"JavaScript\" type=\"text/javascript\">\r\n");
      out.write("function Focus(obj)\r\n");
      out.write("{\r\n");
      out.write("  obj.style.background = '#cc00cc';\r\n");
      out.write("}\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("function Blur(obj)\r\n");
      out.write("{\r\n");
      out.write("  obj.style.background = '#00cc00';\r\n");
      out.write("}\r\n");
      out.write("</script>\r\n");
      out.write("</HEAD>\r\n");
      out.write("\r\n");
      out.write("<BODY>\r\n");
      out.write("\r\n");
      out.write("<TABLE width=710 border=0>\r\n");
      out.write("<TR>  <!-- 第1行 -->\r\n");
      out.write("\t<TD><IMG SRC=\"images/SiteLogo.jpg\" WIDTH=\"150\" HEIGHT=\"70\" BORDER=\"0\" ALT=\"Site Logo\"></TD>\r\n");
      out.write("\t<TD colspan=2><IMG SRC=\"images/ads.jpg\" WIDTH=\"560\" HEIGHT=\"70\" BORDER=\"0\" ALT=\"Ads\"></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR bgcolor=\"#333366\" > <!-- 第2行 -->\r\n");
      out.write("    <td><A HREF=\"/OnlineCDStore/\"><FONT COLOR=\"#FFFFFF\">Link</A></FONT></td>\r\n");
      out.write("\t<TD colspan=2 ALIGN=\"right\"><A href=\"/OnlineCDStore/ViewCart\"><FONT COLOR=\"#FFFFCC\">購物車內容</FONT></A> <FONT COLOR=\"#FFFFCC\">| 結帳</FONT></TD>\r\n");
      out.write("</TR>\r\n");
      out.write("<TR> <!-- 第3行  -->\r\n");
      out.write("\t<TD valign=top> <!-- 第3行 (3,1) -->\r\n");
      out.write("\t\t<TABLE >\r\n");
      out.write("\t\t\t<TR> <!-- 主選單 -->\r\n");
      out.write("\t\t\t\t<TD>\r\n");
      out.write("\t\t\t\t\t<table style=\"border: 1px solid #C8C8C8;width=170\">\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td bgcolor=\"#CCCCFF\" >\r\n");
      out.write("\t\t\t\t\t\t\t主選單\r\n");
      out.write("\t\t\t\t\t\t   </td></tr>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td>\r\n");
      out.write("\t\t\t\t\t\t\t- <a href=\"/OnlineCDStore/\">首頁</A>\r\n");
      out.write("\t\t\t\t\t\t   </td>\r\n");
      out.write("\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td bgcolor=\"#ffffff\" >\r\n");
      out.write("\t\t\t\t\t\t\t- <A href=\"/OnlineCDStore/ViewCatalog\">瀏覽產品</A>\r\n");
      out.write("\t\t\t\t\t\t   </td>\r\n");
      out.write("\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td bgcolor=\"#ffffff\" >\r\n");
      out.write("\t\t\t\t\t\t\t- <A href=\"/OnlineCDStore/ViewCatalog\">男歌手</A>\r\n");
      out.write("\t\t\t\t\t\t   </td>\r\n");
      out.write("\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t<td bgcolor=\"#ffffff\" >\r\n");
      out.write("\t\t\t\t\t\t\t- <A href=\"/OnlineCDStore/ViewCatalog\">女歌手</A>\r\n");
      out.write("\t\t\t\t\t\t   </td>\r\n");
      out.write("\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t\t<TR> <!-- 搜尋表格 -->\r\n");
      out.write("\t\t\t\t<TD>\r\n");
      out.write("\t\t\t\t\t\t<table style=\"border: 1px solid #C8C8C8;width=170\">\r\n");
      out.write("\t\t\t\t\t\t\t<tr>\r\n");
      out.write("\t\t\t\t\t\t\t<td bgcolor=\"#CCCCFF\" >\r\n");
      out.write("\t\t\t\t\t\t\t<FORM METHOD=POST ACTION=\"/OnlineCDStore/SearchMusicCDByName\">\r\n");
      out.write("\t\t\t\t\t\t\t關鍵字:\r\n");
      out.write("\t\t\t\t\t\t\t<tr><td>\r\n");
      out.write("\t\t\t\t\t\t\t<INPUT TYPE=\"text\" NAME=\"keyword\">\r\n");
      out.write("\t\t\t\t\t\t\t</td></tr>\r\n");
      out.write("\t\t\t\t\t\t\t<tr><td>\r\n");
      out.write("\t\t\t\t\t\t\t<INPUT TYPE=\"submit\" name=\"search\">\r\n");
      out.write("\t\t\t\t\t\t\t</td></tr>\r\n");
      out.write("\t\t\t\t\t\t\t</FORM>\r\n");
      out.write("\t\t\t\t\t\t\t</td>\r\n");
      out.write("\t\t\t\t\t\t\t</tr>\r\n");
      out.write("\t\t\t\t\t\t</table>\r\n");
      out.write("\t\t\t\t</TD>\r\n");
      out.write("\t\t\t</TR>\r\n");
      out.write("\t\t</TABLE>\r\n");
      out.write("\t</TD> \r\n");
      out.write("\t<!-- 可變化內容區 (3,2) -->\r\n");
      out.write("\t<TD colspan=2 valign=top>\r\n");
      out.write("\t\r\n");
      out.write("專輯名稱\r\n");
      out.write("<table style=\"border: 1px solid #C8C8C8;\">\r\n");
      out.write("<TR ALIGN=CENTER VALIGN=CENTER bgcolor='#CCCCFF'>\r\n");
      out.write("<TH>專輯名稱</TH><TH>演唱者</TH><TH>售價</TH><TH>細節</TH><TH>購買</TH></TR>\r\n");
      out.write("\r\n");
 
catalog = (Catalog)request.getAttribute("catalog");

for(int i = 0; i < catalog.getCds().size(); i++) {
	MusicCDDesc cd = (MusicCDDesc) catalog.getCds().get(i);

      out.write("\r\n");
      out.write("\r\n");
      out.write("<tr>\r\n");
      out.write("\r\n");
      out.write("<td width='200' align='left'><font size=-1>\r\n");
      out.print( cd.getTitle() );
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("<td width='150' align='left'><font size=-1>\r\n");
      out.print( cd.getSinger() );
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("<td width='70' align='center'><font size=-1>\r\n");
      out.print( cd.getUnitPrice() );
      out.write("\r\n");
      out.write("</td>\r\n");
      out.write("<td width='70' align='center'><font size=-1>\r\n");
      out.write("<A HREF=\"/OnlineCDStore/ShowDetail?cdid=");
      out.print( cd.getMusicCDID() );
      out.write("\">查看細節</A>\r\n");
      out.write("</td>\r\n");
      out.write("<td>\r\n");
      out.write("<a href=\"/OnlineCDStore/AddQuantity?cdid=");
      out.print( cd.getMusicCDID() );
      out.write("\"><font size=-1>\r\n");
      out.write("加入購物車</A>\r\n");
      out.write("</td>\r\n");
      out.write("</tr>\r\n");
 } 
      out.write("\r\n");
      out.write("</table>\r\n");
      out.write("\t</TD>  <!-- 可變化內容區 (3,2) -->\r\n");
      out.write("</TR>\r\n");
      out.write("</TABLE>\r\n");
      out.write("\r\n");
      out.write("\r\n");
      out.write("</BODY>\r\n");
      out.write("</HTML>");
    } catch (Throwable t) {
      if (!(t instanceof SkipPageException)){
        out = _jspx_out;
        if (out != null && out.getBufferSize() != 0)
          out.clearBuffer();
        if (_jspx_page_context != null) _jspx_page_context.handlePageException(t);
      }
    } finally {
      if (_jspxFactory != null) _jspxFactory.releasePageContext(_jspx_page_context);
    }
  }
}
